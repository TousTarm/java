public class Main {
    public static void main(String[] args) {
        Evidence mojeEvidence = TestovaciData.getEvidence();
        mojeEvidence.vypisSeznam();
    }
}