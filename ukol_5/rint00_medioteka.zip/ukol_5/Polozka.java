public interface Polozka {
    String getTitul();  // metoda pro získání titulu
    String getTyp();    // metoda pro získání typu (CD nebo Video)
}
