public class Main {
    public static void main(String[] args){
        HadaniSlov h = new HadaniSlov();
        h.show();
    }
}
